#pragma once
#include"EnemyObject.h"
class BatEnemy:
	public EnemyObject
{
public:
	BatEnemy();
	~BatEnemy();
};

