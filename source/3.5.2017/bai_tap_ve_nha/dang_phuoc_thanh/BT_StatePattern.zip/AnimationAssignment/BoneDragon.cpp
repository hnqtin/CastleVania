#include "BoneDragon.h"



BoneDragon::BoneDragon()
{
	setPhysicsEnable(false);
}


BoneDragon::~BoneDragon()
{
}
