#pragma once
#include "EnemyObject.h"
class BoneDragon :
	public EnemyObject
{
public:
	BoneDragon();
	~BoneDragon();
};

