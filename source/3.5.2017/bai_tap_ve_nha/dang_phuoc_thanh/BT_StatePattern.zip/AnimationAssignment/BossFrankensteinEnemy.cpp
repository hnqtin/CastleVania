#include "BossFrankensteinEnemy.h"



BossFrankensteinEnemy::BossFrankensteinEnemy()
{
}


BossFrankensteinEnemy::~BossFrankensteinEnemy()
{
}
