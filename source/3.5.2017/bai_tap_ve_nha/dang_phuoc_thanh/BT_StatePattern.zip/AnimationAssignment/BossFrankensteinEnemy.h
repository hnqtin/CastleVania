#pragma once
#include"EnemyObject.h"
class BossFrankensteinEnemy : public 
	EnemyObject
{
public:
	BossFrankensteinEnemy();
	~BossFrankensteinEnemy();
};

