#include "Candle.h"



Candle::Candle()
{
}


Candle::~Candle()
{
}
