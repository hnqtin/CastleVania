#include "GameTest.h"
#include"Config.h"
#include "math.h"



GameTest * GameTest::instance = 0;
GameTest * GameTest::getInstance()
{
	if (instance == 0)
		instance = new GameTest();
	return instance;
}

void GameTest::init()
{
	xHinh = 0;	
	yHinh = 0; 
	dx = 1;
	dy = 0;
	hinh.Init("Data/Misc/bong1.png", D3DCOLOR_XRGB(255, 255, 255));

}
void GameTest::update()
{  
	xHinh += dx;
	yHinh += dy;
	switch (bongState)
	{
	case BONG1:
		dx = 1;
		dy = 0;
		if (xHinh + hinh.Width >= BACKBUFFER_WIDTH)
			bongState = BONG2;	
		break;
	case BONG2:
		dx = 0;
		dy = 1;
		if (yHinh + hinh.Height >= BACKBUFFER_HEIGHT)
			bongState = BONG3;		
		break;
	case BONG3:
		dx = -1;
		dy = 0;
		if (xHinh < 0)
			bongState = BONG4;
		break;
	case BONG4:
		dx = 0;
		dy = -1;
		if (yHinh < 0)
			bongState = BONG1;		
		break;
	default:
		break;
	}
}

void GameTest::render()
{
	hinh.RenderTexture(xHinh, yHinh, 0);
}
GameTest::GameTest()
{
}


GameTest::~GameTest()
{
}
