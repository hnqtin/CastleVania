#pragma once
#include"Texture.h"
class GameTest
{
	static GameTest* instance;

	Texture hinh;
	int xHinh, yHinh;
	double r ;
	float dx, dy;
	enum BONG_STATE
	{
		BONG1,
		BONG2,
		BONG3,
		BONG4
	};
	BONG_STATE bongState;

public:
	static GameTest* getInstance();
	void init();
	void update();
	void render();
	GameTest();
	~GameTest();
};

