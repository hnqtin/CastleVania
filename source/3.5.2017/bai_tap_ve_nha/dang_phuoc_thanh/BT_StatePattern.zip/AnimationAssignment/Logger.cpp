#include "Logger.h"



Logger::Logger()
{
}


Logger::~Logger()
{
}
