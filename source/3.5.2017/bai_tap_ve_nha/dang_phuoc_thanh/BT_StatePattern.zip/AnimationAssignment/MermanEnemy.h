#pragma once
#include"EnemyObject.h"
class MermanEnemy 
	: public EnemyObject
{
public:
	MermanEnemy();
	~MermanEnemy();
};

