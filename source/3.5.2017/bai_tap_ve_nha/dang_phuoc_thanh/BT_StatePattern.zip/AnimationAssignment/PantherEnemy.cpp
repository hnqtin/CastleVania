#include "PantherEnemy.h"



PantherEnemy::PantherEnemy()
{
}


PantherEnemy::~PantherEnemy()
{
}
