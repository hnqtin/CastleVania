#pragma once
#include "EnemyObject.h"
class PantherEnemy :
	public EnemyObject
{
public:
	PantherEnemy();
	~PantherEnemy();
};

