#pragma once
class Point
{
public:
	int X, Y;

	Point(int x=0,int y=0);

	void set(int x = 0, int y = 0);

	~Point();
};

