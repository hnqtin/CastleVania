#include "ZombieEnemy.h"



ZombieEnemy::ZombieEnemy()
{
}


ZombieEnemy::~ZombieEnemy()
{
}
