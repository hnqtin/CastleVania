#pragma once
#include "EnemyObject.h"
class ZombieEnemy :
	public EnemyObject
{
public:
	ZombieEnemy();
	~ZombieEnemy();
};

