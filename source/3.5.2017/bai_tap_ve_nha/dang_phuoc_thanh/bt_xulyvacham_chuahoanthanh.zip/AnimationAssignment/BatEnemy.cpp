#include "BatEnemy.h"



BatEnemy::BatEnemy()
{
}


BatEnemy::~BatEnemy()
{
}
