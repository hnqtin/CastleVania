#pragma once
#include"BaseObject.h"
class Candle : 
	public BaseObject
{
public:
	Candle();
	~Candle();
};

