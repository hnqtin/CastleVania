#pragma once

enum COLLISION_TYPE
{
	CT_GROUND,
	CT_ENEMY,
	CT_PLAYER,
	CT_WEAPON,
	CT_ITEM,
	CT_ALL,
	CT_COUNT
};
