#include<fstream>
#include<string>
using namespace std;
void ignoreLineIfstream(ifstream& fs, int lineCount);