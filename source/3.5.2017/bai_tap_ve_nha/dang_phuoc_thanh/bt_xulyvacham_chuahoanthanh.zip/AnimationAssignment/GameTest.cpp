#include "GameTest.h"
#include"Config.h"
#include"FpsManager.h"
#include"ConsoleLogger.h"
#include"SimonPlayer.h"
#include"SpriteManager.h"
#include"CollisionTest.h"
#include"KEY.h"


GameTest * GameTest::instance = 0;
GameTest * GameTest::getInstance()
{
	if (instance == 0)
		instance = new GameTest();
	return instance;
}

void GameTest::init()
{
	xHinh2 = 10;
	yHinh2 = 10;
	xHinh3 = 80;
	yHinh3 = 10;
	xHinh4 = 160;
	yHinh4 = 10;
	dx = 1;
	dy = 1;
	a = 2.0f;
	v = 0;

	//r = 20.0f;
	//y00 = 20;
	//hinh.Init("Data/Sprites/Simon/image.png", D3DCOLOR_XRGB(255, 255, 255));

	//vx = 0;
	//vy = 20.0f; // 10 pixel/s

	//ay = 0.0f; // 0 (pixel/s)/s

	calculateTime.setTimePerFrame(2.0f); // 2s

	cancelLog = false;
	calculateTime.StartCounter_r();

	rects = new RECT[2];

	animationFrameIndex = 0;

	timeDelay.setTickPerFrame(100);//100 ms

	//SetRect(&rects[0], 97, 64, 97 + 37, 64 + 37);
	//SetRect(&rects[1], 129, 69, 130 + 15, 69 + 30);

	//simonSprite = new Sprite();
	//simonSprite->ReadFromFile("Data/misc/info.simple.txt", "Data/misc/image.png");
	//actionIndex = params["actionIndex"];
	//frameIndex = 1;
	simonObj.setLocation(10, 180);
	simonObj.sprite = SpriteManager::getSprite(SI_SIMON);;
	simonObj.actionIndex = SIMON_PLAYER_ACTION_SIMON_ATTACK_SIT;
	simonObj.frameIndex = 0;
	simonObj.setSize(16, 24);

	simonObj2.setLocation(80, 180);
	simonObj2.sprite = SpriteManager::getSprite(SI_SIMON);;
	simonObj2.actionIndex = SIMON_PLAYER_ACTION_SIMON_ATTACK;
	simonObj2.frameIndex = 0;
	simonObj2.setSize(16, 24);


	simonObj3.setLocation(160, 180);
	simonObj3.sprite = SpriteManager::getSprite(SI_SIMON);;
	simonObj3.actionIndex = SIMON_PLAYER_ACTION_SIMON_ATTACK3;
	simonObj3.frameIndex = 0;
	simonObj3.setSize(16, 24);



	tuong.sprite = new Sprite();
	tuong.sprite->initFromSingleFrame("Data/Misc/tuong.png");
	tuong.setLocation(0, 80);
	tuong.setSize(315, 5);

}
void GameTest::update()
{
	//// kiem tra va cham
	//// xu ly va cham
	//xHinh += dx;
	//yHinh += dy;

	//double timeGame = _FpsManager->getTimeGame();

	//if (timeDelay.atTime())
	//{
	//	sprite2->update(actionIndex2, frameIndex2);
	//}	
	//if (calculateTime.CanCreateFrame() && !cancelLog)
	//{
	//	consoleLogger->LogLine(yHinh);
	//	cancelLog = true;
	//}


	simonObj.update();
	int d = 2;
	simonObj2.update();
	int d2 = 2;
	simonObj3.update();
	int d3 = 2;
	//if (KEY::getInstance()->isUpDown)
	//{
	//	simonObj.setDy(d);
	//	simonObj.setDx(0);
	//}
	//else if (KEY::getInstance()->isDownDown)
	//{
	//	simonObj.setDy(-d);
	//	simonObj.setDx(0);

	//}
	//else if (KEY::getInstance()->isLeftDown)
	//{

	//	simonObj.setDy(0);
	//	simonObj.setDx(-d);
	//}
	//else if (KEY::getInstance()->isRightDown)
	//{

	//	simonObj.setDy(0);
	//	simonObj.setDx(d);
	//}
	//else
	//{
	//	simonObj.setDx(0);
	//	simonObj.setDy(0);
	//}

	// tinh dx va dy cua 1 vat

	// kiem tra va xu ly va cham bang cach sua dx va dy
	CollisionTest::CheckCollision(&simonObj, &tuong);
	CollisionTest::CheckCollision(&simonObj2, &tuong);
	CollisionTest::CheckCollision(&simonObj3, &tuong);

	// cap nhat dx va dy moi cho vat
	simonObj.setX(simonObj.getX() + simonObj.getDx());
	simonObj.setY(simonObj.getY() + simonObj.getDy());

	simonObj2.setX(simonObj2.getX() + simonObj2.getDx());
	simonObj2.setY(simonObj2.getY() + simonObj2.getDy());

	simonObj3.setX(simonObj3.getX() + simonObj3.getDx());
	simonObj3.setY(simonObj3.getY() + simonObj3.getDy());


}
void GameTest::render()
{
	simonObj.render();
	simonObj2.render();
	simonObj3.render();
	tuong.render();
}
GameTest::GameTest()
{
	moveState = MOVE1;
}


GameTest::~GameTest()
{
}
