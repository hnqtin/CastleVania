#pragma once
#include"Texture.h"

#include"GameTime.h"
#include"FpsManager.h"
#include"Sprite.h"
#include"TestObject.h"

enum MOVE_STATE
{
	MOVE1,
	MOVE2,
	MOVE3
};



class GameTest
{
	static GameTest* instance;

	RECT* rects;

	Texture hinh;
	float xHinh2, yHinh2, xHinh3, yHinh3, xHinh4, yHinh4;
	float r, alpha, y00;

	int dx, dy;
	float a,v ;

	MOVE_STATE moveState;

	FpsManager calculateTime;

	int animationFrameIndex;

	GameTime timeDelay;



	bool cancelLog;

	int actionIndex;
	int frameIndex;
	Sprite* simonSprite;

	//Sprite* sprite2;
	//int actionIndex2;
	//int frameIndex2;
	TestObject simonObj;
	TestObject simonObj2;
	TestObject simonObj3;
	TestObject tuong;

public:
	static GameTest* getInstance();
	void init();
	void update();
	void render();
	GameTest();
	~GameTest();
};

