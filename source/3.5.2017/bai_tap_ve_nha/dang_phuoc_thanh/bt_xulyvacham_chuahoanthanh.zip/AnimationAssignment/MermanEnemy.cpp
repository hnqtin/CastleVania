#include "MermanEnemy.h"



MermanEnemy::MermanEnemy()
{
}


MermanEnemy::~MermanEnemy()
{
}
