﻿#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Hinh2Chieu
{
public:
	virtual float tinhDienTich() = 0;
	virtual void read(ifstream& ifs) = 0;
	virtual void In() = 0;
};
// hinh tron
class HinhTron : public Hinh2Chieu
{
	float xtam, ytam, bankinh;
public:
	HinhTron()
	{
		slh++;
	}
	float tinhDienTich();
	static int slh;
	void read(ifstream& ifs)
	{
		ifs >> xtam >> ytam >> bankinh;
	}
	void In()
	{
		cout << "[ R :" << bankinh << ",O: (" << xtam << "," << ytam << ") ]" << endl;
	}
};
int HinhTron::slh = 0;
float HinhTron::tinhDienTich()
{
	return 3.14*bankinh*bankinh;
}
// hinh chu nhat
class HinhChuNhat : public Hinh2Chieu
{
	float xTopleft, yTopleft, width, height;
public:
	float tinhDienTich();
	void read(ifstream& ifs)
	{
		ifs >> xTopleft >> yTopleft >> width >> height;
	}

	void In()
	{
		int left = xTopleft;
		int right = xTopleft + width;
		int top = yTopleft;
		int bottom = yTopleft + height;
		printf("[TopLeft(%d,%d), TopRight(%d,%d), BottomLeft(%d,%d), BottomRight(%d,%d)]\n",
			left, top, right, top, left, bottom, right, bottom
		);
	}
};

float HinhChuNhat::tinhDienTich()
{
	return width * height;
}
// hinh vuong
class HinhVuong : public Hinh2Chieu
{
	float xTopleft, yTopleft, canh;
public:
	float tinhDienTich();
	void read(ifstream& ifs)
	{
		ifs >> xTopleft >> yTopleft >> canh;
	}

	void In()
	{
		int left = xTopleft;
		int right = xTopleft + canh;
		int top = yTopleft;
		int bottom = yTopleft + canh;
		printf("[TopLeft(%d,%d), TopRight(%d,%d), BottomLeft(%d,%d), BottomRight(%d,%d)]\n",
			left, top, right, top, left, bottom, right, bottom
		);
	}
};

float HinhVuong::tinhDienTich()
{
	return canh * canh;
};
// doc file
void ignoreLineIfstream(ifstream& fs, int lineCount)
{
	string s;
	for (int i = 0; i < lineCount; i++)
	{
		getline(fs, s);
	}
}

int main()
{
	ifstream ifs("bai1.inp.txt");
	int slh;
	int loai;
	ignoreLineIfstream(ifs, 1);
	ifs >> slh;
	ignoreLineIfstream(ifs, 2);
	Hinh2Chieu* obj = 0;
	Hinh2Chieu** arr = new Hinh2Chieu*[slh];
	for (int i = 0; i < slh; i++)
	{
		ifs >> loai;
		switch (loai)
		{
		case 0:
			obj = new HinhTron();
			break;
		case 1:
			obj = new HinhVuong();
			break;
		case 2:
			obj = new HinhChuNhat();
			break;
		default:
			break;
		}
		obj->read(ifs);
		arr[i] = obj;
	}

	for (size_t i = 0; i < slh; i++)
	{
		arr[i]->In();
	}

	cout << "so luong hinh tron :" << HinhTron::slh;

	system("pause");
	//ifstream fs;
	//fs.open("C:\game_castlevani\source\bai tap\bai tap quad tree\bai1.inp.txt", ios::in);
	//string data;
	//getline(fs, data);
	//fs.close();
	//cout << data <<endl;
}

