﻿#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Hinh2Chieu
{
public:
	virtual float tinhDienTich() = 0;
};
// hinh tron
class HinhTron : public Hinh2Chieu
{
	float xtam, ytam, bankinh;
public:
	float tinhDienTich();
};

float HinhTron::tinhDienTich()
{
	return 3.14*bankinh*bankinh;
}
// hinh chu nhat
class HinhChuNhat : public Hinh2Chieu
{
	float xTopleft, yTopleft, width, height;
public:
	float tinhDienTich();
};

float HinhChuNhat::tinhDienTich()
{
	return width*height;
}
// hinh vuong
class HinhVuong : public Hinh2Chieu
{
	float xTopleft, yTopleft, canh;
public:
	float tinhDienTich();
};

float HinhVuong::tinhDienTich()
{
	return canh * canh;
};
// doc file
void ignoreLineIfstream(ifstream& fs, int lineCount)
{
	string s;
	for (int i = 0; i < lineCount; i++)
	{
	getline(fs, s);
	}
}

int main()
{
	ifstream fs;
	fs.open("C:\game_castlevani\source\bai tap\bai tap quad tree\bai1.inp.txt", ios::in);
	string data;
	getline(fs, data);
	fs.close();
	cout << data <<endl;
}

	